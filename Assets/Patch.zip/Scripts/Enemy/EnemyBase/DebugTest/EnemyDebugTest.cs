using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "ScriptableObject/EnemyDestroyBlink")]
public class EnemyDebugTest : ScriptableObject
{
    public DebugTest test = new DebugTest();
}