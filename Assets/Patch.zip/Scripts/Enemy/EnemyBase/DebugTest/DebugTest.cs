using System;
using Unity.VisualScripting;
using UnityEngine;

[Serializable]
public class DebugTest
{
 


    //public void DestroyBlinkSpeedSet(out float[] speed)
    //{
    //    speed = destroyBlinkSpeed;
    //}
    //public void DestroyBlinkColorSet(out Color clr)
    //{
    //    clr = color;
    //}
}
