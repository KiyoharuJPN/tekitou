using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IEventStart
{
    public void EventStart(PlayerController player);
}
